from langchain.text_splitter import TokenTextSplitter
from langchain.schema import Document
import re

# Your existing classify_chunk function here, or import it if defined elsewhere
def score_mcq(text):
    score = 0
    score += text.count("প্রশ্ন") * 2
    score += text.count("উত্তর")
    score += len(re.findall(r"[১২৩৪৫৬৭৮৯০]{1,2}[।\.]", text))
    return score

def score_glossary(text):
    if "শব্দার্থ ও টীকা" in text:
        return 3
    if "শব্দ" in text and "অর্থ" in text:
        return 2
    return 0

def score_passage(text):
    if len(text) < 800:
        return 0
    punct_count = text.count("।") + text.count(".")
    short_lines = sum(1 for line in text.splitlines() if len(line.strip()) < 30)
    return (punct_count * 2) - short_lines

def classify_chunk(text):
    mcq = score_mcq(text)
    glossary = score_glossary(text)
    passage = score_passage(text)
    if glossary >= 3:
        return "Glossary"
    elif mcq >= 4 and mcq > passage:
        return "MCQ"
    elif passage > 6 and passage > mcq:
        return "Passage"
    else:
        return "Other"

# def extract_and_label_chunks():
#     with open("ocr_output.txt", "r", encoding="utf-8") as file:
#         full_text = file.read()

#     splitter = TokenTextSplitter(chunk_size=512, chunk_overlap=50)
#     chunks = splitter.split_text(full_text)

#     labeled_chunks = []

#     for chunk in chunks:
#         text = chunk.strip()
#         metadata = {}

#         if "লেখক পরিচিতি" in text:
#             metadata["section"] = "Author Introduction"
#         elif any(word in text for word in ["পাঠ্যসূচি", "পাঠ্যবিষয়ক", "পাঠ পরিচিতি"]):
#             metadata["section"] = "Lesson Introduction"
#         else:
#             metadata["section"] = classify_chunk(text)

#         labeled_chunks.append(Document(page_content=text, metadata=metadata))

#     return labeled_chunks

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document

def extract_and_label_chunks():
    with open("ocr_output.txt", "r", encoding="utf-8") as file:
        full_text = file.read()

    splitter = RecursiveCharacterTextSplitter(
        separators=["\n\n", "\n", ".", "?", "!", " "],  # try natural boundaries first
        chunk_size=512,
        chunk_overlap=100,
        length_function=len  # default is len(characters), you can override for tokens if you want
    )
    chunks = splitter.split_text(full_text)

    docs = [Document(page_content=chunk.strip()) for chunk in chunks]
    return docs


if __name__ == "__main__":
    docs = preprocess_text()
    print(f"Generated {len(docs)} token-based chunks")
    for i in range(min(5, len(docs))):
        print(f"Chunk {i+1} (Section: {docs[i].metadata.get('section', 'N/A')}):\n{docs[i].page_content[:500]}...\n")
