import sys
sys.stdout.reconfigure(encoding='utf-8')
# Your existing code
from pdf2image import convert_from_path
import pytesseract
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

images = convert_from_path("book.pdf")
# for i, image in enumerate(images[:-1]):
#     text = pytesseract.image_to_string(image, lang='ben+eng')
#     print(f"\n--- Page {i+1} ---\n{text}")
# print("আমার সোনার বাংলা")

text_pages = []
for i, image in enumerate(images[:-1]):
    text = pytesseract.image_to_string(image, lang='ben+eng')
    text_pages.append(f"\n--- Page {i+1} ---\n{text}")

# Save to file
with open("ocr_output.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(text_pages))

