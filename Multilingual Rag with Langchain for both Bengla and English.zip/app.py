# app.py
import streamlit as st
import requests

st.set_page_config(page_title="📚 Bangla RAG App", layout="wide")
st.markdown("<h1 style='text-align: center;'>বাংলা প্রশ্নোত্তর অ্যাপ</h1>", unsafe_allow_html=True)

API_URL = "http://localhost:5000"  # adjust if deploying remotely

if st.button("🔄 প্রসেস চালু করুন"):
    with st.spinner("✂️ চাংক ও ক্লাসিফিকেশন হচ্ছে..."):
        res = requests.post(f"{API_URL}/process")
        if res.ok:
            st.success(f"✅ {res.json()['message']} ({res.json()['num_chunks']} chunks)")
        else:
            st.error(f"❌ ত্রুটি: {res.text}")

question = st.text_input("❓ একটি প্রশ্ন লিখুন", placeholder="উদাহরণ: অপরিচিতা গল্পের লেখক কে?")

if st.button("🤖 প্রশ্ন করুন"):
    if not question:
        st.warning("⚠️ প্রথমে প্রশ্ন লিখুন।")
    else:
        with st.spinner("🧠 উত্তর তৈরি হচ্ছে..."):
            res = requests.post(f"{API_URL}/ask", json={"question": question})
            if res.ok:
                data = res.json()
                st.markdown(f"### ✅ উত্তর:\n<div style='font-family: Kalpurush;'>{data['answer']}</div>", unsafe_allow_html=True)
                st.markdown("##### 📚 সোর্স:")
                for src in data["sources"]:
                    st.markdown(f"<div style='font-family: Kalpurush;'>{src['content']}</div>", unsafe_allow_html=True)
                    st.markdown("---")
            else:
                st.error(f"❌ ত্রুটি: {res.text}")
