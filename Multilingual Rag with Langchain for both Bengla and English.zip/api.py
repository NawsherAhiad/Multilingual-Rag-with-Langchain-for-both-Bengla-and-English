# ---------- api.py (Flask Backend) ----------
from flask import Flask, request, jsonify
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.schema import Document
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
import preprocess
import re
import os
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
app = Flask(__name__)

os.environ["GOOGLE_API_KEY"] = "AIzaSyAbQ22ht51ee5H_dG8906nT3DF1LsLQrTo"

embedding = HuggingFaceEmbeddings(model_name="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
llm = ChatGoogleGenerativeAI(model="models/gemini-1.5-flash", temperature=0, convert_system_message_to_human=True)




qa_prompt = PromptTemplate(
    input_variables=["context", "question"],
    template=(
        "তুমি একজন বুদ্ধিমান প্রশ্নোত্তর সহকারী। তুমি শুধুমাত্র প্রদত্ত তথ্য ব্যবহার করে প্রশ্নের উত্তর দেবে। "
        "তথ্য না থাকলে 'তথ্য নেই' বলবে।\n\n"
        "প্রসঙ্গ:\n{context}\n\n"
        "প্রশ্ন: {question}\n\n"
        "উত্তর বাংলায় সংক্ষেপে এবং নির্ভুলভাবে দাও:"
    )
)

def groundedness_score(answer, context_text):
    try:
        answer_emb = evaluation_model.encode([answer])
        context_emb = evaluation_model.encode([context_text])
        score = cosine_similarity(answer_emb, context_emb)[0][0]
        return round(score, 3)
    except Exception as e:
        print("Error in groundedness scoring:", e)
        return 0.0


def extract_keywords(query):
    stopwords = {"এবং", "কিন্তু", "তবে", "কি", "কে", "কোন", "আমি", "তুমি", "সে", "কত"}
    tokens = re.findall(r'\w+', query)
    return [t for t in tokens if t not in stopwords and len(t) > 1]

def filter_docs_by_keywords(docs, keywords):
    return [doc for doc in docs if any(k in doc.page_content for k in keywords)]

@app.route("/process", methods=["POST"])
def process_text():
    print("📥 /process request received")
    try:
        chunks = preprocess.extract_and_label_chunks()
        docs = [Document(page_content=chunk.page_content, metadata=chunk.metadata) for chunk in chunks]
        print(f"✅ Extracted {len(docs)} chunks")
        return jsonify({"message": "চাংকিং সম্পন্ন", "num_chunks": len(docs)}), 200
    except Exception as e:
        print("❌ Error in /process:", e)
        return jsonify({"error": str(e)}), 500



if __name__ == "__main__":
    app.run(debug=False, port=5000, use_reloader=False)


# ---------- app.py (Streamlit Frontend) ----------
import streamlit as st
import requests

st.set_page_config(page_title="📚 Bangla RAG App", layout="wide")
st.markdown("<h1 style='text-align: center;'>বাংলা প্রশ্নোত্তর অ্যাপ</h1>", unsafe_allow_html=True)

API_URL = "http://localhost:5000"

if st.button("🔄 প্রসেস চালু করুন"):
    with st.spinner("✂️ চাংক ও ক্লাসিফিকেশন হচ্ছে..."):
        res = requests.post(f"{API_URL}/process")
        if res.ok:
            st.success(f"✅ {res.json()['message']} ({res.json()['num_chunks']} chunks)")
        else:
            st.error(f"❌ ত্রুটি: {res.text}")

question = st.text_input("❓ একটি প্রশ্ন লিখুন", placeholder="উদাহরণ: অপরিচিতা গল্পের লেখক কে?")

if st.button("🤖 প্রশ্ন করুন"):
    if not question:
        st.warning("⚠️ প্রথমে প্রশ্ন লিখুন।")
    else:
        with st.spinner("🧠 উত্তর তৈরি হচ্ছে..."):
            res = requests.post(f"{API_URL}/ask", json={"question": question})
            if res.ok:
                data = res.json()
                st.markdown(f"### ✅ উত্তর:\n<div style='font-family: Kalpurush;'>{data['answer']}</div>", unsafe_allow_html=True)
                st.markdown("##### 📚 সোর্স:")
                for src in data["sources"]:
                    st.markdown(f"<div style='font-family: Kalpurush;'>{src['content']}</div>", unsafe_allow_html=True)
                    st.markdown("---")
            else:
                st.error(f"❌ ত্রুটি: {res.text}")
