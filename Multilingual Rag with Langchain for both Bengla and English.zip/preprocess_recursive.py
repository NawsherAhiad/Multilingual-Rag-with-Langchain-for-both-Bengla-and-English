# import re
# from langchain.text_splitter import RecursiveCharacterTextSplitter

# def score_mcq(text):
#     score = 0
#     score += text.count("প্রশ্ন") * 1.5  # Slightly lower weight
#     score += text.count("উত্তর")
#     score += len(re.findall(r"[১২৩৪৫৬৭৮৯০]{1,2}[।\.]", text)) * 0.5
#     return score

# def score_glossary(text):
#     if "শব্দার্থ ও টীকা" in text:
#         return 2.5  # Lowered to match "less rigorous"
#     if "শব্দ" in text and "অর্থ" in text:
#         return 2
#     return 0

# def score_passage(text):
#     if len(text) < 500:  # Reduced length requirement
#         return 0
#     punct_count = text.count("।") + text.count(".")
#     short_lines = sum(1 for line in text.splitlines() if len(line.strip()) < 20)  # Less strict
#     return (punct_count * 1.5) - short_lines

# def classify_chunk(text):
#     mcq = score_mcq(text)
#     glossary = score_glossary(text)
#     passage = score_passage(text)

#     if glossary >= 2:
#         return "Glossary"
#     elif mcq >= 3 and mcq > passage:
#         return "MCQ"
#     elif passage > 4 and passage > mcq:
#         return "Passage"
#     else:
#         return "Other"

# def extract_and_label_chunks():
#     with open("ocr_output.txt", "r", encoding="utf-8") as file:
#         full_text = file.read()

#     splitter = RecursiveCharacterTextSplitter(
#         separators=["\n\n", "\n"],
#         chunk_size=1200,          # More generous chunks
#         chunk_overlap=100         # Slight overlap to preserve context
#     )
#     chunks = splitter.split_text(full_text)

#     labeled_chunks = []
#     for chunk in chunks:
#         text = chunk.strip()
#         metadata = {}

#         # Hardcoded sections
#         if "লেখক পরিচিতি" in text:
#             metadata["section"] = "Author Introduction"
#         elif any(word in text for word in ["পাঠ্যসূচি", "পাঠ্যবিষয়ক", "পাঠ পরিচিতি"]):
#             metadata["section"] = "Lesson Introduction"
#         else:
#             metadata["section"] = classify_chunk(text)

#         labeled_chunks.append({
#             "content": text,
#             "metadata": metadata
#         })

#     # Preview only the first few for sanity check
#     for i, chunk in enumerate(labeled_chunks[:10]):
#         print(f"\nChunk {i}:")
#         print("Section:", chunk["metadata"]["section"])
#         print("Preview:", chunk["content"][:250].replace("\n", " "))
#         print("-" * 60)

#     return labeled_chunks

# if __name__ == "__main__":
#     extract_and_label_chunks()

import re
import nltk
nltk.download('punkt')
from langchain.text_splitter import RecursiveCharacterTextSplitter

# --- Step 1: Clean the OCR text ---
def clean_text(text):
    # Remove OCR noise and unnecessary symbols
    text = re.sub(r'©|\[.*?\]|\> MINUTE|TG Xcode|HSC \d+|[^\S\r\n]{2,}', '', text)
    text = re.sub(r'\n+', '\n', text)  # Collapse multiple newlines
    text = re.sub(r'[‘’“”]', "'", text)
    return text.strip()

# --- Step 2: Split into paragraphs (optional step) ---
def chunk_by_paragraph(text):
    paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
    return paragraphs

# --- Step 3: Extract MCQ blocks (optional for analysis) ---
def chunk_mcq(text):
    mcqs = re.findall(r'\d+[।\.] .*?\n(?:[ক-ঘ]\) .*?\n)+', text)
    return mcqs

# --- Step 4: RAG-ready text chunking ---
def create_rag_chunks(text, chunk_size=1000, chunk_overlap=100):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ".", " ", ""]
    )
    return splitter.split_text(text)

def extract_and_label_chunks():
    with open("ocr_output.txt", "r", encoding="utf-8") as file:
        full_text = file.read()

    cleaned_text = clean_text(full_text)
    paragraph_chunks = chunk_by_paragraph(cleaned_text)
    full_text = "\n\n".join(paragraph_chunks)
    rag_chunks = create_rag_chunks(full_text)

    labeled_chunks = []
    for i, chunk in enumerate(rag_chunks):
        labeled_chunks.append({"content": chunk, "metadata": {"chunk_id": i+1}})
    return labeled_chunks



extract_and_label_chunks()
    

