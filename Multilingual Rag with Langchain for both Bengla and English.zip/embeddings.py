from langchain_community.vectorstores import FAISS
from langchain.schema import Document
from langchain_huggingface import HuggingFaceEmbeddings
import preprocess_recursive as preprocess

embedding = HuggingFaceEmbeddings(
    model_name="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
    model_kwargs={"device": "cpu"}
)


docs = [
    Document(page_content=chunk["content"], metadata=chunk["metadata"])
    for chunk in preprocess.extract_and_label_chunks()
]

vectorstore = FAISS.from_documents(docs, embedding)
vectorstore.save_local("faiss_multilingual")


vectorstore = FAISS.load_local(
    "faiss_multilingual",
    embeddings=embedding,
    allow_dangerous_deserialization=True
)
retriever = vectorstore.as_retriever()

query = "অপরিচিতা গল্পের লেখক কে?"
results = retriever.get_relevant_documents(query)

for doc in results:
    print("Section:", doc.metadata.get("section", ""))
    print("Content:", doc.page_content[:300])
    print("-" * 50)
 

# if __name__ == "__main__":
#     model = get_embedding_model()
#     print("Embedding model loaded successfully.")
#     # Example usage
#     example_text = "This is a test sentence."
#     embedding = model.embed_query(example_text)
#     print(f"Embedding for '{example_text}': {embedding[:5]}...")  # Printing first 5 dimensions